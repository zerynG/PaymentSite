from django.contrib import admin
from .models import Customer

@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ['inn', 'customer_type', 'name', 'full_name', 'email', 'phone']
    list_filter = ['customer_type']
    search_fields = ['inn', 'name', 'full_name', 'email']
    ordering = ['-created_at']