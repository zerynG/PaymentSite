from django.contrib import admin
from django.urls import path, include
from django.shortcuts import redirect

def redirect_to_auth(request):
    return redirect('login:auth')

urlpatterns = [
    path('', redirect_to_auth),  # Перенаправление с корня на auth/
    path('admin/', admin.site.urls),
    path('', include('login.urls')),  # Включаем URLs из приложения main
    path('workspace/', include('workspace.urls')),
    path('customers/', include('customers.urls')),  # URL для приложения customers
]